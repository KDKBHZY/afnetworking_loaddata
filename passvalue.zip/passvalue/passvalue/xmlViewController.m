//
//  xmlViewController.m
//  passvalue
//
//  Created by formssi on 2021/5/26.
//  Copyright © 2021 formssi. All rights reserved.
//

#import "xmlViewController.h"
#import "AFNetworking.h"

@interface xmlViewController ()<NSXMLParserDelegate>

@end

@implementation xmlViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    self.str = @"";
    self.strarr = [[NSMutableArray alloc]init];

    //[self loaddata];
    [self loadxml];
       
}

//-(void) loaddata{
//        dispatch_async(dispatch_get_global_queue(0, 0), ^{
//               [self loadxml];
//            if(self.strarr.count!=0){
//                            dispatch_async(dispatch_get_main_queue(), ^{
//                                for(int i = 0;i<self.strarr.count;i++){
//                                      self.str = [self.str stringByAppendingString:self.strarr[i]];
//                                  }
//                                NSLog(@"拼接后：%@",self.str);
//                                self.context.text = self.str;
//
//
//                           });
//                       // });
//
//
//            }
//
//
//        });
//}


-(void)loadxml{
     dispatch_async(dispatch_get_global_queue(0, 0), ^{
    AFHTTPSessionManager *aft = [AFHTTPSessionManager manager];
    NSString*xmlurl = @"http://www.webxml.com.cn/WebServices/WeatherWebService.asmx/getWeatherbyCityName?theCityName=59287";
      xmlurl = [xmlurl stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];
   aft.responseSerializer = [AFXMLParserResponseSerializer serializer];

//    dispatch_queue_t queque = dispatch_queue_create("Created1", DISPATCH_QUEUE_CONCURRENT);
        // dispatch_async(queque, ^{
             //self.semaphore = dispatch_semaphore_create(0);

       [aft GET:xmlurl parameters:nil success:^(NSURLSessionDataTask * _Nonnull task, NSXMLParser* responseObject) {
             responseObject.delegate =self;
             [responseObject parse];
             NSLog(@"%@",responseObject);
//           if(self.strarr.count!=0){
//               dispatch_semaphore_signal(self.semaphore);
//
//           }
           //if(self.strarr.count!=0){
                       dispatch_async(dispatch_get_main_queue(), ^{

                           for(int i = 0;i<self.strarr.count;i++){
                                 self.str = [self.str stringByAppendingString:self.strarr[i]];
                             }
                           NSLog(@"拼接后：%@",self.str);
                           self.context.text = self.str;

                      });
          // }
             
         } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
             NSLog(@"xml获取失败:%@",error);
         }];
            //dispatch_semaphore_wait(self.semaphore, DISPATCH_TIME_FOREVER);

       //  });
  });
    
}
//NSXMLParser 的代理方法 五步骤的解析
//- (void)parserDidStartDocument:(NSXMLParser *)parser{
//    NSLog(@"1 开始解析");
//}
//- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary<NSString *,NSString *> *)attributeDict{
//    NSLog(@"2 开始节点 %@ %@",elementName,attributeDict);
//}

- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string{
    //NSLog(@"节点之间的内容 %@",string);

    [self.strarr addObject:string ];
  
  //  NSLog(@"拼接后：%@",self.str);

}

//- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName{
//    NSLog(@"3 结束节点 %@",elementName);
//}
//
//
//- (void)parserDidEndDocument:(NSXMLParser *)parser{
//    NSLog(@"5 结束解析");
//    NSLog(@"");
//}
- (void)parser:(NSXMLParser *)parser parseErrorOccurred:(NSError *)parseError{
    NSLog(@"6 错误");
}


@end
