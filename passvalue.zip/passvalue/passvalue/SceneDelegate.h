//
//  SceneDelegate.h
//  passvalue
//
//  Created by formssi on 2021/5/18.
//  Copyright © 2021 formssi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

