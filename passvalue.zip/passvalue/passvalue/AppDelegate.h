//
//  AppDelegate.h
//  passvalue
//
//  Created by formssi on 2021/5/18.
//  Copyright © 2021 formssi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

