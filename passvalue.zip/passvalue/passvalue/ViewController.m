//
//  ViewController.m
//  passvalue
//
//  Created by formssi on 2021/5/18.
//  Copyright © 2021 formssi. All rights reserved.
//

#import "ViewController.h"
#import "AFNetworking.h"
#import "MJRefresh.h"
#import "UIImageView+WebCache.h"

@interface ViewController ()<UITableViewDelegate,UITableViewDataSource>

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.lo = [[NSLock alloc] init];
    self.lo1 = [[NSLock alloc] init];
    self.names = [[NSMutableArray alloc] init];
          self.singers = [[NSMutableArray alloc] init];
    self.images = [[NSMutableArray alloc] init];

    self.searchname = self.searchtext.text;
    //设置textfield的默认值
       if ([self.searchname  isEqual: @""]) {
               self.searchname = @"周杰伦";
       }
      // NSLog(@"%@",self.searchname);
      
    //[self loaddata:self.searchname];
      
         MJRefreshHeader *header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{

            [self loaddata:self.searchname];
            
         }];
         self.tbview.mj_header = header;
         [self.tbview.mj_header beginRefreshing];
    self.tbview.delegate = self;
                               self.tbview.dataSource = self;
    
    //添加手势，编辑结束时收起键盘
           UITapGestureRecognizer* tap1 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(fingerta:)];
           [self.view addGestureRecognizer:tap1];
//    [self.view addSubview:self.tbview];
//       dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
       
  //  });
  
}

- (IBAction)click:(id)sender {
    NSString*url = @"hzytest://hzy?name=hzy&phone=1382928786";
    if([[UIApplication sharedApplication]canOpenURL:[NSURL URLWithString:url] ]){
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:url] options:@{} completionHandler:^(BOOL success) {
            NSLog(@"打开成功");
        }];
    }else{
        NSLog(@"没有安装urlscheme！！！");
    }
}

- (IBAction)search:(id)sender {
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
          [self.names removeAllObjects];
             [self.singers removeAllObjects];
           [self.images removeAllObjects];
          [self loaddata:self.searchname];
           dispatch_async(dispatch_get_main_queue(), ^{
               [self.searchtext resignFirstResponder];
               [self textFieldShouldEndEditing:self.searchtext];

               [self.tbview reloadData];
               [self.tbview layoutIfNeeded];

           });
    });
  
   

}

//AFnetworking网络请求，请求网络数据
-(void)loaddata:(NSString*) search{
    [self.names removeAllObjects];
         [self.singers removeAllObjects];
       [self.images removeAllObjects];
    //创建一个线程队列，确保先拿到数据后，再进行tableview加载
    dispatch_queue_t queque = dispatch_queue_create("Created", DISPATCH_QUEUE_CONCURRENT);
    dispatch_async(queque, ^{
self.semaphore = dispatch_semaphore_create(0);
        AFHTTPSessionManager*mgr = [AFHTTPSessionManager manager];
           //获取歌曲基本信息的url
           NSString*url = [NSString stringWithFormat:@"https://autumnfish.cn/search?keywords=%@",search];
           NSLog(@"%@",search);
           //处理含有中文的url
             url = [url stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];
           [mgr GET:url parameters:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                 NSDictionary* result = [responseObject objectForKey:@"result"];
               NSArray* music = [result objectForKey:@"songs"];

               for(int i=0;i<music.count;i++){
                     NSDictionary*song = [music objectAtIndex:i];
                     //获取并解析歌曲名
                     self.name = [song objectForKey:@"name"];
                     [self.names addObject:self.name];
                    NSString* musicid = [song objectForKey:@"id"];
                     //NSLog(@"%@ :%@", musicid ,self.name);
                  
                     [self loaddetail:musicid];
                                     }
                     } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                         NSLog(@"失败！！！%@",error);
                     }];
        dispatch_semaphore_wait(self.semaphore, DISPATCH_TIME_FOREVER);
        NSLog(@"count%lu",(unsigned long)self.singers.count);
        dispatch_async(dispatch_get_main_queue(), ^{
              [self.tbview reloadData];
              [self.tbview layoutIfNeeded];

             });
          [self.tbview.mj_header endRefreshing];
       });
    

   


    

}

- (nonnull UITableViewCell *)tableView:(nonnull UITableView *)tableView cellForRowAtIndexPath:(nonnull NSIndexPath *)indexPath {
   
        UITableViewCell*cell1 = [tableView dequeueReusableCellWithIdentifier:@"cellid"];
   
         NSString*mname = [self.names objectAtIndex:indexPath.row];
         cell1.textLabel.text = mname;
         //因为有的歌曲是n位歌手演唱，所以要再建一个数组,来循环解析获取到的歌手数组
         NSArray*snames = [self.singers objectAtIndex:indexPath.row];
         NSString*sname = @"";
         int scount = snames.count;
         while (scount!=0) {
             scount-=1;
             sname=[sname stringByAppendingString:[snames objectAtIndex:scount]];
         }
         cell1.detailTextLabel.text = sname;
  
   
    [cell1.imageView sd_setImageWithURL:[self.images objectAtIndex:indexPath.row] placeholderImage:[UIImage imageNamed:@"img1"] ];
         return cell1;
    
 
}

- (NSInteger)tableView:(nonnull UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    NSLog(@"tb count%lu",(unsigned long)self.names.count);
        return self.names.count ;
}

//获取歌曲详情
-(void)loaddetail:(NSString*)musicid{
  
    //获取歌曲详细信息的url
    AFHTTPSessionManager *mgr = [AFHTTPSessionManager manager];

    NSString*url1 =[NSString stringWithFormat:@"https://autumnfish.cn/song/detail?ids=%@",musicid] ;
                                   //处理含有中文的url
                                url1 = [url1 stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];
    
    [mgr GET:url1 parameters:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject1) {
                                    NSArray* result = [responseObject1 objectForKey:@"songs"];
                                   NSDictionary*details = [result objectAtIndex:0];
        NSArray*objects = [details objectForKey:@"ar"];
        NSDictionary*imgobjets = [details objectForKey:@"al"];
        NSString*imgurl = [imgobjets objectForKey:@"picUrl"];
       // NSLog(@"%@",imgurl);
       [self.images addObject:imgurl];
       
         NSMutableArray*all = [[NSMutableArray alloc] init];
                                    for(int i=0;i<objects.count;i++){
                                         NSDictionary*details1 = [objects objectAtIndex:i];
                                       
                                        NSString*singer = [details1 objectForKey:@"name"];
                                       singer = [NSString stringWithFormat:@"%@    ",singer];
                                       // NSLog(@"%@",singer);
                                        [all addObject:singer];
                                        //获取并解析图片
                                        }
        //完成全部的数据获取，将信号量变为1

      if((self.images.count) == self.names.count ){
                          dispatch_semaphore_signal(self.semaphore);
       
                     }

        [self.singers addObject:all];

                                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                                    NSLog(@"失败！！！%@",error);
                                }];
}

//取消键盘方法
-(void) fingerta:(UITapGestureRecognizer *)gestureRecognizer{
    [self.view endEditing:YES];
}

-(BOOL)textFieldShouldEndEditing:(UITextField *)textField
{
    self.searchname = textField.text;

    NSLog(@"textField - text - %@",self.searchname);
    return YES;
}

@end
